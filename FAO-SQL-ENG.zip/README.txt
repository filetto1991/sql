In the folder are the csv file downloaded from the FAO site,
the same file in sql format (which contains the query to create the database and the table),
and finally the query file with all my analyses and comments.
