-- Let's take a first look at the entire database
SELECT * FROM mytable;
-- let's make it more readable
SELECT country, commodity, year, loss_percentage, 
loss_quantity, food_supply_stage FROM mytable;
-- all columns except loss_quantity and food_supply_stage are not null
-- let's see how many nulls we have in those columns
SELECT COUNT(loss_quantity) FROM mytable
WHERE loss_quantity IS NOT NULL;
-- unfortunately we only have 4552 not nulls out of a total of 27773 rows
SELECT COUNT(food_supply_stage) FROM mytable
WHERE food_supply_stage IS NOT NULL;
-- the nulls in food_supply_stage are very few, let's proceed
-- let's count the countries
SELECT COUNT(DISTINCT country) FROM mytable;
-- we have 149 countries in the database (continents such as Africa and Latin America are also included)
-- let's try to figure out which countries waste the most
SELECT country, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY country
ORDER BY mean DESC;
-- here is the ranking by percentage of waste
-- as above but in reverse, starting with the most virtuous countries
SELECT country, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY country
ORDER BY mean;
-- let's see which types of food are the most wasted
SELECT commodity, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY commodity
ORDER BY mean DESC;
-- as above but starting with the least wasted foods
SELECT commodity, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY commodity
ORDER BY mean;
-- let's see if we get better or worse over the years
SELECT year, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY year
ORDER BY mean DESC;
-- I do not see a correlation
-- to conclude, let's look at waste according to the various stages of production
SELECT food_supply_stage, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY food_supply_stage
ORDER BY mean;
-- here the results are quite clear
