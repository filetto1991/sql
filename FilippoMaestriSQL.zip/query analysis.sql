-- diamo una prima occhiata a tutto il database
SELECT * FROM mytable;
-- rendiamolo piu leggibile
SELECT country, commodity, year, loss_percentage, 
loss_quantity, food_supply_stage FROM mytable;
-- tutte le colonne ad accezione di loss_quantity e food_supply_stage sono not null
-- vediamo quanti null abbiamo in quelle colonne
SELECT COUNT(loss_quantity) FROM mytable
WHERE loss_quantity IS NOT NULL;
-- purtroppo abbiamo solo 4552 not null su un totale di 27773 righe
SELECT COUNT(food_supply_stage) FROM mytable
WHERE food_supply_stage IS NOT NULL;
-- i null in food_supply_stage sono pochissimi, procediamo
-- contiamo i paesi
SELECT COUNT(DISTINCT country) FROM mytable;
-- abbiamo 149 paesi nel database (sono inclusi anche continenti come africa e america latina)
-- cerchiamo di capire quali paesi sprecano di piu
SELECT country, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY country
ORDER BY mean DESC;
-- ecco la classifica per percentuale di spreco
-- come sopra ma al contrario, partendo dai paesi piu virtuosi
SELECT country, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY country
ORDER BY mean;
-- vediamo quali tipi di cibo vengono maggiormente sprecati
SELECT commodity, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY commodity
ORDER BY mean DESC;
-- come sopra ma partendo dai cibi meno sprecati
SELECT commodity, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY commodity
ORDER BY mean;
-- vediamo se con gli anni miglioriamo o peggioriamo
SELECT year, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY year
ORDER BY mean DESC;
-- non vedo una correlazione
-- per concludere vediamo lo spreco in base alle varie fasi di produzione
SELECT food_supply_stage, AVG(loss_percentage) AS 'mean' FROM mytable
GROUP BY food_supply_stage
ORDER BY mean;
-- qui i risultati sono abbastanza chiari