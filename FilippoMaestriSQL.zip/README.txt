Nella cartella sono presenti il file csv scaricato dal sito FAO,
lo stesso file in formato sql (che contiene la query per creare il database e la tabella),
infine il file con le query con tutte la mie analisi e relativi commenti.